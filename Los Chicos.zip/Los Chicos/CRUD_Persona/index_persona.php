<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://kit.fontawesome.com/646ac4fad6.js" crossorigin="anonymous"></script>
</head>
<body>
    <h1 class= "text-center p-3">"Los Chicos""</h1>
    <div class="container-fluid row">
        <form class= "col-4 p-3" method="POST">
            <h3 class="text-center text-rbg">Registro de Personas</h3>
            <?php
            include "Modelo_persona/conexion.php";
            include "Controlador_persona/registro_persona.php";
           ?> 
            <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Apellido Paterno</label>
                <input type="text" class="form-control" name="ap_paterno" >
            </div>
            <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Apellido Materno</label>
                <input type="text" class="form-control" name="ap_materno" >
            </div>
            <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Nombre</label>
                <input type="text" class="form-control" name="ap_nombre" >
            </div>
            <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Número de Documento</label>
                <input type="text" class="form-control" name="nro_documento" >
            </div>
            <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Feha de Nacimieto</label>
                <input type="date" class="form-control" name="fecha_nacimiento" >
            </div>
            <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Telefono</label>
                <input type="text" class="form-control" name="telefono" >
            </div>
            <button type="submit" class="btn btn-primary" name="btnregistrar" value="ok">Registrar</button>
        </form>
        <div class="col-8 p-4">
            <table class="table">
                <thead class="bg-info">
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">APELLIDO PATERNO</th>
                        <th scope="col">APELLIDO MATERNO</th>
                        <th scope="col">NOMBRE</th>
                        <th scope="col">NRO DOCUMENTO</th>
                        <th scope="col">FECHA_NACIMIENTO</th>
                        <th scope="col">TELEFONO</th>
                        <th scope="col"></th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    include "Modelo_persona/conexion.php";
                    $sql = $conexion->query("select * from persona");
                    while ($datos = $sql->fetch_object()){
                    ?> 
                    <tr>
                        <td><?= $datos->id ?></td>
                        <td><?= $datos->ap_paterno ?></td>
                        <td><?= $datos->ap_materno ?></td>
                        <td><?= $datos->ap_nombre ?></td>
                        <td><?= $datos->nro_documento ?></td>
                        <td><?= $datos->fecha_nacimiento ?></td>
                        <td><?= $datos->telefono ?></td>
                        <td>
                            <a href="modificar_persona.php?id<?=$datos->id ?>" class="btn btn-small btn-green"><i class="fa-solid fa-pen-to-square"></i></a>
                            <a Onclick="return eliminar()" href="index_persona.php?id<?=$datos->id ?>" class="btn btn-small btn-danger"><i class="fa-solid fa-trash-can"></i></a>
                        </td>
                    </tr>
                    <?php
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>