<?php

if (!empty($_POST["btnregistrar"])){
    if (!empty($_POST["ap_paterno"]) and !empty($_POST["ap_materno"]) and !empty($_POST["ap_nombre"]) and !empty($_POST["nro_documento"]) and !empty($_POST["fecha_nacimiento"]) and !empty($_POST["telefono"])) {

        $ap_paterno=$_POST["ap_paterno"];
        $ap_maternno=$_POST["ap_materno"];
        $ap_nombre=$_POST["ap_nombre"];
        $nro_documento=$_POST["nro_documento"];
        $fecha_nacimiento=$_POST["fecha_nacimiento"];
        $telefono=$_POST["telefono"];

        $sql=$conexion->query("insert into persona (ap_paterno,ap_materno,ap_nombre,nro_documento,fecha_nacimiento,telefono)values('$ap_paterno','$ap_maternno','$ap_nombre','$nro_documento','$fecha_nacimiento','$telefono')");

        if ($sql==1) {
            echo '<div class="alert alert-success">Persona Registrado Correctamente</div>';
        } else {
            echo '<div class="alert alert-danger">Error al Registrar Persona</div>';
        }
        
    } else {
        echo '<div class="alert alert-warning">Alguno de los Campos estan Vacio</div>';
    }
}
?>