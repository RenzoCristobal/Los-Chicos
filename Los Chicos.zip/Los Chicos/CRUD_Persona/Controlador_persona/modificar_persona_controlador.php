<?php

if (!empty($_POST["btnregistrar"])) {
    if (!empty($_POST["ap_paterno"]) and !empty($_POST["ap_materno"]) and !empty($_POST["ap_nombre"]) and !empty($_POST["nro_documento"]) and !empty($_POST["fecha_nacimiento"]) and !empty($_POST["telefono"])) {
        
        $id=$_POST["id"];
        $ap_paterno=$_POST["ap_paterno"];
        $ap_maternno=$_POST["ap_materno"];
        $ap_nombre=$_POST["ap_nombre"];
        $nro_documento=$_POST["nro_documento"];
        $fecha_nacimiento=$_POST["fecha_nacimiento"];
        $telefono=$_POST["telefono"];
        $sql=$conexion->query(" update producto set ap_paterno='$ap_paterno', ap_materno='$ap_maternno', ap_nombre='$ap_nombre', nro_documento='$nro_documento', fecha_nacimiento='$fecha_nacimiento', telefono='$telefono' where id_persona=$id");

        if ($sql==1) {
            header ("location:index.php");
        } else {
            echo "<div class='alert alert-warning'>Error al Modificar Persona</div>";
        }
        
    } else {
        echo "<div class='alert alert-warning'>Campos Vacios</div>";
    }
}

?>