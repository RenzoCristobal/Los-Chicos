<?php
$conexion = new mysqli("localhost", "root", "", "los_chicos");
?>